from unittest import TestCase
from classes.GoogleCustomSearchApi import GoogleCustomSearchApi
from googleapiclient.errors import HttpError


class TestGoogleCustomSearchApi(TestCase):
    def test_google_search(self):
        googleApi = GoogleCustomSearchApi()
        try:
            pdf_path = googleApi.search("06020101 HSMR-Rapport-2015-2017.pdf")
            self.assertAlmostEqual(pdf_path, "https://www.umcg.nl/SiteCollectionDocuments/UMCG/Kwaliteit/HSMR-Rapport-2015-2017.pdf")
        except HttpError as ex:
            pass
        except Exception as ex:
            self.fail('Unexpected exception raised:', ex)
