from unittest import TestCase
from classes.FileDownloader import FileDownloader
from classes.LocalSettings import LocalSettings
import os


class TestFileDownloader(TestCase):
    def test_download_pdf_from_url(self):
        localSettings = LocalSettings()
        file_path = "https://www.umcg.nl/SiteCollectionDocuments/UMCG/Kwaliteit/HSMR-Rapport-2015-2017.pdf"
        test_file_name = "testFile"

        fileDownloader = FileDownloader()
        fileDownloader.download_pdf_from_url(file_path, test_file_name)
        total_file_name = "{}.pdf".format(test_file_name)
        total_file_path = os.path.join(localSettings.get_setting("temp_dir"), total_file_name)

        #check if file is present
        if os.path.isfile(total_file_path):
            #file is found, remove the rest file
            os.remove(total_file_path)
        else:
            self.fail("Could not download the PDF file")