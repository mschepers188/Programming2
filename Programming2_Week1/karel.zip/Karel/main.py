from classes.CcsHospitalDataExtracter import CcsHospitalDataExtracter


def main():
    ccs_hospital_data_extracter = CcsHospitalDataExtracter()
    ccs_hospital_data_extracter.main()


if __name__ == "__main__":
    main()
