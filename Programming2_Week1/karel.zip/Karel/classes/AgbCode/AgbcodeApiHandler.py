import requests
from classes.LocalSettings import LocalSettings
import os
import json
import pandas as pd
from classes.AgbCode.AgbCodeData import AgbCodeData


class AgbcodeApiHandler:
    localSettings = LocalSettings()

    def __init__(self, hospital_type):
        """
        Class to get the Agb codes and related information from the official database with the dutch AGB api codes
        :param hospital_type: Type of the hospital (normal, academic). Type constants are defined in hospital_types.pu
        """

        self.apiUrl = self.localSettings.get_setting("agb_code_api_url")
        self.data = ""
        self.hospital_type = hospital_type
        self.temp_file_name = "agb_code_request_data_{}.json".format(hospital_type)

    def has_data(self):
        """
        Check is data is available
        :return: bool
        """

        return self.data != ""

    def get_data_as_json(self):
        """
        Get the data as parsed json
        :return: list with objects
        """

        return self.data

    def get_agb_code_data(self):
        """
        Get the Agb data as AgbCodeData data object
        :return: AgbCodeData object
        """

        if self.has_data():
            return AgbCodeData(pd.DataFrame(self.data))
        return None

    def extract_data_from_api(self):
        """
        Fetch the data from the web with the api
        :return:
        """

        print("Get data: {}, from api".format(self.hospital_type))
        params = {
            "ZorgpartijType": "0",
            "Naam": "",
            "NaamComparer": "1",
            "AGBCode": "",
            "AGBCodeComparer": "1",
            "DatumAanvangInschrijvingComparer": "0",
            "DatumAanvangInschrijving": "",
            "DatumEindeInschrijvingComparer": "0",
            "DatumEindeInschrijving": "",
            "Postcode": "",
            "Plaats": "",
            "rNummer": "",
            "Status": "0",
            "Zorgsoort": "06",
            "Kwalificaties": self.hospital_type
        }

        r = requests.post(url=self.apiUrl, data=params, headers=self.localSettings.get_setting("agb_code_api_headers"))
        self.data = r.json()

    def get_temp_file_path(self):
        """
        get the filepath filepath of the temperary saved data
        :return: String
        """

        return os.path.join(self.localSettings.get_setting('temp_dir'), self.temp_file_name)

    def has_temp_file(self):
        """
        Check if a temperary file with is saved
        :return: bool
        """

        return os.path.isfile(self.get_temp_file_path())

    def extract_data_from_temp_json_file(self):
        """
        Method to extract the data from the earlier saved JSON file.
        :return:
        """

        path = self.get_temp_file_path()
        file = open(path)
        self.data = json.load(file)
        file.close()

    def create_json_output_file(self):
        """
        Method to create a json output file of the data which is obtained from the API.
        :return:
        """

        if self.has_data():
            path = self.get_temp_file_path()
            file = open(path, 'w')
            json.dump(self.data, file)
            file.close()

    def extract_data(self, create_temp_file_if_not_present=True):
        """
        Method to get the data. When a temperary file is earlier saved in the tempdir,
        the data of this file will be loaded instead of the API request. When no temperary file is present, the data
        will be fetched and processed from the API. When the parameter boolean "create_temp_file_if_not_present"
        is set to true, the temperary file will be created after with the data from the API request
        :param create_temp_file_if_not_present: bool: True, a temperary file with the data from the API will be created
        :return:
        """

        if self.has_temp_file():
            self.extract_data_from_temp_json_file()
        else:
            self.extract_data_from_api()
            if create_temp_file_if_not_present:
                self.create_json_output_file()
