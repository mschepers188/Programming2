

# Agb identicator code of a academic hospital
ACADEMY_HOSPITAL = "0602"

# Agb identicator code of a general hospital
GENERAl_HOSPITAL = "0601"
