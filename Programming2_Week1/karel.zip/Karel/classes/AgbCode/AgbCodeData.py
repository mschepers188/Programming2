

class AgbCodeData:
    def __init__(self, dataframe):
        """
        Class to save and support the datatable which hold the AgbCode data
        :param dataframe: the Pandas dataframe with the AgbCode data
        """

        self.df = dataframe

    def get_dataframe(self):
        """
        Method to get the Pandas dataframe
        :return: Pandas dataframe
        """

        return self.df

    def remove_empty_agb_codes(self):
        """
        Method to remove the rows in the dataset which do not contain a Agb Code
        :return:
        """

        self.df.dropna(subset=['AGBCode'], inplace=True)

    def get_agb_codes(self):
        """
        Get the Agb codes as numpy array
        :return: numpy array
        """

        return self.df.loc[:, "AGBCode"].values
