from classes.CcsClassification import CcsClassification
from classes.LocalSettings import LocalSettings
from classes.HsmrReportHandler import HsmrReportHandler
import glob
import os


class HsmrReportsReader:
    localSettings = LocalSettings()

    def __init__(self):
        """
        Class to read and parse all the available HSMR reports in the temp directory
        """
        self.ccs_category_info = None

    def read_files(self):
        """
        Method to parse all the available HSMR reports
        :return:
        """

        self.get_ccs_category_info()
        report_file_paths = self.get_hsmr_file_paths()
        ccs_data = []
        if report_file_paths is not None:
            for report in report_file_paths:
                ccs_single_hospital_data = self.parse_single_hsmr_file(report)
                ccs_data.append(ccs_single_hospital_data)
        return ccs_data

    def get_ccs_category_info(self):
        """
        Method to read the Ccs classification information
        :return:
        """

        self.ccs_category_info = CcsClassification(self.localSettings.get_setting("ccs_category_info_csv_file_path"))

    def parse_single_hsmr_file(self, file_path):
        """
        Method parse a single HSMR report file and return the ccs information
        :param file_path: String path to the HSMR report
        :return: CcsHospitalInfo object
        """

        report_handler = HsmrReportHandler(file_path, self.ccs_category_info)
        ccs_data = report_handler.get_ccs_info()
        return ccs_data

    def get_hsmr_file_paths(self):
        """
        Method to get the paths of all the HSMR pdf reports present in the temp directory
        :return: list with Strings with the paths to the PDF reports
        """

        file_search_name = "hsmr-report_*.pdf"
        file_search_path = os.path.join(self.localSettings.get_setting("temp_dir"), file_search_name)
        hsmr_report_files = glob.glob(file_search_path)
        if len(hsmr_report_files) > 0:
            return hsmr_report_files
        return None
