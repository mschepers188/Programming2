from classes.LocalSettings import LocalSettings
from googleapiclient.discovery import build


class GoogleCustomSearchApi:
    localSettings = LocalSettings()

    def __init__(self):
        """
        Class to perform a Custom Google Seearch to find the HSMR reports on
        the website's of the hospital itself
        """

        self.api_key = self.localSettings.get_setting("google_custom_search_api_key")
        self.search_engine_id = self.localSettings.get_setting("google_search_engine_id")

    def search(self, search_text):
        """
        Overall method to search to perform the Google search to find the HSMR reports and process the
        results to identity the URL to the report file
        :param search_text: String, the search text
        :return: String with the url to the HSMR pdf report if the file is found, otherwise None
        """

        search_results = self.google_search(search_text)
        if search_results and len(search_results) > 0:
            return self.search_for_hsmr_pdf_file(search_results)
        return None

    def google_search(self, search_term):
        """
        Mehtod to perform a custom search based on the given search term. If the search results in results
        the result will be returned, otherwise the method returns None
        :param search_term: String, the search text
        :return: List with the search results if present otherwise None
        """

        service = build("customsearch", "v1", developerKey=self.api_key)
        res = service.cse().list(q=search_term, cx=self.search_engine_id).execute()
        if 'items' in res:
            return res['items']
        return None

    @staticmethod
    def search_for_hsmr_pdf_file(results):
        """
        Method to process the Google results and identify the pdf file with the HSMR report.
        If the report is found, the path to the find will be returned. If the file is not found, None will be given
        :param results: List with the Custom Google search results
        :return: String with the URL to the HSMR pdf report if identified, otherwise None
        """

        for line in results:
            if 'link' in line and line['link'].endswith(".pdf"):
                if 'snippet' in line:
                    if "HSMR-rapport 2015-2017" in line['snippet'] or "HSMR-rapport 2015-2017" in line['title']:
                        return line['link']
        return None
