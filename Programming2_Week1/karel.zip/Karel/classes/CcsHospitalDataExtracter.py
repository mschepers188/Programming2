from classes.LocalSettings import LocalSettings
from classes.Plotter import Plotter
from classes.HsmrReportFetcher import HsmrReportsFetcher
from classes.HsmrReportsReader import HsmrReportsReader
from classes.AgbCode.hospital_types import ACADEMY_HOSPITAL, GENERAl_HOSPITAL


class CcsHospitalDataExtracter:
    """
    This program can be used to
    """
    localSettings = LocalSettings()

    def __init__(self):
        self.hospital_types = [ACADEMY_HOSPITAL, GENERAl_HOSPITAL]


    def main(self):
        """
        This is the overall method which exectute all the functionality of the parser
        1. identify the dirrent hospitals based
        :return:
        """

        try:
            self.fetch_hsmr_reports()
        except Exception as ex:
            print("Error during fetching:", str(ex))

        try:
            ccs_data = self.read_hsmr_files()
            self.create_plot(ccs_data)
        except Exception as ex:
            print("Error during parsing ccs data:", str(ex))


    def create_plot(self, ccs_hospital_info):
        """
        Method to create the plot based on the ccs data from the hospital
        :param ccs_hospital_info:
        :return:
        """

        plotter = Plotter(ccs_hospital_info)
        plotter.create_plot()
        plotter.show_plot()

    def fetch_hsmr_reports(self):
        """
        Method to identify and download the HSMR reports
        :return:
        """

        fetcher = HsmrReportsFetcher()
        fetcher.fetch_files(self.hospital_types)

    def read_hsmr_files(self):
        """
        Method to read the HSMR reports saved in the temporary directory
        :return: list with CcsHospitalInfo objects
        """

        reader = HsmrReportsReader()
        return reader.read_files()
