# HSMR PDF based report constant
HSMR_REPORT_PDF = "HSMR_REPORT_PDF"

# HSMR text based report constant
HSMR_REPORT_TEXT = "HSMR_REPORT_TEXT"
