from classes.HsmrFileParsers.HsmrParser import HsmrParser


class HsmrTextParser(HsmrParser):
    """
    Child to class to parse text based Hsmr reports
    """

    def read_file(self):
        """
        Implementation of the parse method to parse HSMR text files
        :return:
        """

        if self.has_file_path():
            text_file = open(self.file_path)
            self.file_content = text_file.read()
