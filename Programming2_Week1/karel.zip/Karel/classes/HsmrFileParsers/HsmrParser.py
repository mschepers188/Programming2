from abc import ABCMeta, abstractmethod
import pandas as pd
from classes.LocalSettings import LocalSettings
from utilities import get_clean_number_list
from classes.CcsClassification import CcsClassification as Ccs
from classes.CcsHospitalInfo import CcsHospitalInfo
from classes.AgbCode.hospital_types import ACADEMY_HOSPITAL


class HsmrParser(metaclass=ABCMeta):
    localSettings = LocalSettings()

    def __init__(self, file_path, hospital_type, hospital_code, hospital_name, hospital_city):
        """
        Parent Metaclass for a File parser who can parse a HSMR report
        :param file_path: String, Path to the report file
        :param hospital_type: String hospital type (defined in hospital_types.py)
        :param hospital_code: String Agb Code of the hospital
        :param hospital_name: Hospital name
        :param hospital_city: String city where the hospital is located
        """

        self.file_path = file_path
        self.hospital_type = hospital_type
        self.hospital_code = hospital_code
        self.hospital_name = hospital_name
        self.hospital_city = hospital_city
        self.file_content = None

    def has_file_path(self):
        """
        Method to check if a file path is present
        :return: bool
        """

        return self.file_path is not None and self.file_path != ""

    def get_hospital_name(self):
        """
        Method to get the hospital name
        :return: String
        """

        return self.hospital_name

    def is_umc(self):
        """
        Method to check if the hospital is an academic hospital
        :return:
        """

        return self.hospital_type == ACADEMY_HOSPITAL

    def has_file_content(self):
        """
        Method to check if the file content is loaded / present in the file
        :return: bool
        """
        return self.file_content is not None

    def write_content_to_text_file(self, export_file_path):
        """
        Method to create a text file with the content of the parsed file.
        This method is useful when the data was parsed from a difficult file, like a PDF which costs much type to parse.
        When the parsed data is saved in a text file, the data can later be parsed much easier and faster
        :param export_file_path: String, The name and path which will be used to create the file
        :return:
        """

        if self.file_content is not None and self.file_content != "":
            text_file = open(export_file_path, 'w')
            text_file.write(self.file_content)
            text_file.close()

    def extract_ccs_numbers(self, ccs_info):
        """
        Method to extract the CCS information from the parsed file
        :param ccs_info: CcsClassification object with the ccs classification
        :return: CcsHospitalInfo
        """

        pdf_keys = ccs_info.get_pdf_key_info()
        df = pd.DataFrame(columns=["ccs_index", "ccs_category", "admissions", "real_died", "predicted_died", "SMR"])

        extract_data = False
        pdf_rows = self.file_content.split("\n")
        options_start = self.localSettings.get_setting("hsmr_report_ccs_table_name")
        options_end = self.localSettings.get_setting("hsmr_report_ccs_next_table_name")
        for line in pdf_rows:
            for option in options_start:
                if line.startswith(option):
                    extract_data = True
            for option in options_end:
                if line.startswith(option):
                    extract_data = False

            if extract_data:
                for index, row in pdf_keys.iterrows():
                    if line.startswith(row[Ccs.get_pdf_key()][0:52]):
                        numbers = line.replace(row[Ccs.get_pdf_key()][0:52], "").split(" ")
                        # print(row['name'], numbers)
                        numbers = get_clean_number_list(numbers)
                        if len(numbers) >= 4:
                            # print(row['name'], numbers)
                            pd_row = pd.DataFrame([[row[Ccs.get_ccs_index()],
                                                    row[Ccs.get_ccs_category()], *numbers[0:4]]],
                                                  columns=["ccs_index", "category", "admissions",
                                                           "real_died", "predicted_died", "SMR"])
                            df = pd.concat([df, pd_row], sort=False)
        if df.shape[0] > 0:
            return CcsHospitalInfo(self.hospital_type, self.hospital_code, self.hospital_name, self.hospital_city, df)

        return None

    @abstractmethod
    def read_file(self):
        """
        Method to parse the HSMR report. This method must be implemented in the sub classes
        :return:
        """

        raise NotImplemented("The method read_file must be implemented in the subclass")
