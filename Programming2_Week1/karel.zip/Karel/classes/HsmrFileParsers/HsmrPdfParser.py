import textract
from classes.HsmrFileParsers.HsmrParser import HsmrParser


class HsmrPdfParser(HsmrParser):
    """
    Child to class to parse pdf based Hsmr reports
    """

    def read_file(self):
        """
        Implementation of the parse method to parse HSMR pdf files
        :return:
        """

        if self.has_file_path():
            text = textract.process(self.file_path, method='tesseract', encoding='utf-8')
            self.file_content = text.decode('utf-8')
