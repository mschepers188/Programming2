from classes.HsmrFileParsers.parserTypes import HSMR_REPORT_TEXT, HSMR_REPORT_PDF
from classes.HsmrFileParsers.HsmrPdfParser import HsmrPdfParser
from classes.HsmrFileParsers.HsmrTextParser import HsmrTextParser


class HsmrParserFactory:

    @staticmethod
    def get_instance(parser_type):
        """
        Factory to get the HSMR parser object based on the parser types defined in parser_types.py
        :param parser_type: the parser type, defined as constants in parser_types.py
        :return: child of HsmrParser object
        """

        if parser_type == HSMR_REPORT_PDF:
            return HsmrPdfParser
        if parser_type == HSMR_REPORT_TEXT:
            return HsmrTextParser
