import pandas as pd


class CcsClassification:

    pdf_key = "pdf_key"
    ccs_category_key = "name"
    ccs_index_key = "css_index"

    def __init__(self, file_path):
        """
        Class to handle the Ccs classification information from the corresponded CcsClass information file
        :param file_path: String, path to the ccs classification csv file
        """

        self.file_path = file_path
        self.df = pd.DataFrame()
        self.read_csv_file()

    def read_csv_file(self):
        """
        Method to read the ccs classification ccs file
        :return:
        """

        self.df = pd.read_csv(self.file_path, sep=';')

    def get_dataframe(self):
        """
        Method to get the Pandas dataframe with the ccs classification information
        :return: Pandas dataframe
        """

        return self.df

    def has_pdf_key(self):
        """
        Method to check if the pdf_key column is present in the dataframe
        :return: bool
        """

        return self.pdf_key in self.df.columns.values

    def add_pdf_key_row(self):
        """
        Method to add the pdf_key column to the dataframe and generate the pdf_key for each row in the dataframe
        :return:
        """
        if not self.has_pdf_key():

            def add_key_to_dataframe(row):
                """
                Method to generate the pdf_key based on the information grouped dataframe
                :param row: Pandas dataframe, the information of the grouped dataframe
                :return: orginal pandas dataframe with the added pdf_key column with the generated keys
                """

                css_groups = row.loc[:, "CCS group"]
                name = row.loc[:, "Diagnosegroep_omschrijving (NL)"].iloc[0]
                ccs_group_str = ", ".join([str(x) for x in css_groups.values.tolist()])
                row[self.get_pdf_key()] = "{name} ({ccsGroups})".format(name=name, ccsGroups=ccs_group_str)
                return row

            self.df = self.df.groupby('Diagnosegroep_omschrijving (NL)').apply(add_key_to_dataframe)

    def get_pdf_key_info(self):
        """
        Method to get the a formatted dataframe with the ccs classification information
        :return: Pandas dataframe
        """

        if not self.has_pdf_key():
            self.add_pdf_key_row()

        return self.df.loc[:, ["CCS group", "Diagnosegroep_omschrijving (NL)", "pdf_key"]]\
            .drop_duplicates()\
            .rename(columns={"Diagnosegroep_omschrijving (NL)": self.get_ccs_category(),
                             "CCS group": self.get_ccs_index()})

    @classmethod
    def get_pdf_key(cls):
        """
        Static method to get the column name of the pdf_key column
        :return: string
        """

        return cls.pdf_key

    @classmethod
    def get_ccs_index(cls):
        """
        Static method to get the column name of the ccs_index column
        :return: string
        """

        return cls.ccs_index_key

    @classmethod
    def get_ccs_category(cls):
        """
        Static method to get the column name of the ccs_category column
        :return: string
        """

        return cls.ccs_category_key
