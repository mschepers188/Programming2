from classes.AgbCode.AgbcodeApiHandler import AgbcodeApiHandler
from classes.GoogleCustomSearchApi import GoogleCustomSearchApi
from classes.FileDownloader import FileDownloader
from classes.LocalSettings import LocalSettings
import os


class HsmrReportsFetcher:
    """
    Class to fetch the HSMR reports from the website's of the hospital based on Google search of the
    official hostpital sgc codes. Google search is used to identify the PDF files on the website's.
    The sgc codes are parsed from the official SGC database.
    """

    localSettings = LocalSettings()
    pdf_file_name_template = "hsmr-report_{type}_{code}_{name}_{city}"

    def fetch_files(self, hospital_types):
        """
        This is the overall method which execute the different steps of the identify and download process
        steps:
        1: Fetch the agb codes from the official database, with the api of the website available for the public
        2: Gogole search to find the PDF reports based on the search query with the agb code
        3: Download the report to the temporary directory
        :param hospital_types: Hospital_type list with strings string, constants defined in hosital_types.py
        :return:
        """

        for hos_type in hospital_types:
            agb_dataset_academic = self.get_info_agbcode_info_from_api(hos_type)
            self.download_hsmr_reports_from_sgc_codes(agb_dataset_academic, hos_type)

    def download_hsmr_reports_from_sgc_codes(self, agb_dataset, hos_type):
        """
        Method to find the HSMR reports of the hospitals based on Google search and download the
        HSMR pdf report file from the website to the temporary directory when a correct file is found
        :param agb_dataset: AgbCodeData object which contains the dataframe with the hospital data and the
        corresponded agb code
        :param hos_type: Hospital_type String, constants defined in hosital_types.py
        :return:
        """

        for row in agb_dataset.get_dataframe().iterrows():
            agb_code = row[1]['AGBCode']
            name = row[1]['Naam']
            city = row[1]['Plaats']
            print("Process: ", agb_code, name, city)

            # Check if the report is already downloaded
            file_name = self.pdf_file_name_template.format(type=hos_type,
                                                           code=agb_code,
                                                           name=name,
                                                           city=city)
            total_file_name = "{}.pdf".format(file_name)
            file_path = os.path.join(self.localSettings.get_setting("temp_dir"), total_file_name)
            if not os.path.isfile(file_path):
                search_text = "{} HSMR-Rapport-2015-2017.pdf".format(name)
                search_api = GoogleCustomSearchApi()
                pdf_url = search_api.search(search_text)
                if pdf_url is not None:
                    FileDownloader.download_pdf_from_url(pdf_url, file_name)

    @staticmethod
    def get_info_agbcode_info_from_api(hospital_type):
        """
        Method to get the name, information and corresponded agb code from the official database.
        A web api of the webservice is used to extract the data.
        :param hospital_type: Hospital_type String, constants defined in hosital_types.py
        :return:
        """

        agbcode = AgbcodeApiHandler(hospital_type)
        agbcode.extract_data()
        data = agbcode.get_agb_code_data()
        data.remove_empty_agb_codes()
        return data
