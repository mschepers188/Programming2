import requests
from classes.LocalSettings import LocalSettings
import os


class FileDownloader:
    localSettings = LocalSettings()

    @classmethod
    def download_pdf_from_url(cls, pdf_url, file_name):
        """
        Method to download a PDF file from the web and save them in the temporary directory
        :param pdf_url: String, URL path to the pdf file
        :param file_name: String the name of the pdf file which will be saved in the temporary directory
        :return:
        """

        file_content = requests.get(pdf_url, allow_redirects=True)
        total_file_name = "{}.pdf".format(file_name)
        file_path = os.path.join(cls.localSettings.get_setting('temp_dir'), total_file_name)
        file = open(file_path, "wb")
        file.write(file_content.content)
        file.close()
