import matplotlib.pyplot as plt
from matplotlib import rcParams


class Plotter:
    def __init__(self, ccs_hospital_info_list):
        """
        Class to create a plot based on the Number of hospital deads and Number of patient admissions
        :param ccs_hospital_info_list: List with CcsHospitalInfo objects
        """

        self.ccs_data = ccs_hospital_info_list

    def has_data_to_plot(self):
        """
        Method to check if data is present.
        :return: Bool
        """

        return len(self.ccs_data) > 0

    def create_plot(self):
        """
        Method to create the plot based on the data. A scatter plot will be created with the number of admission
        on the x asis and the number of deads on the y asis
        :return:
        """

        if self.has_data_to_plot():

            umc_data = []
            not_umc_data = []
            for hospital in self.ccs_data:
                if hospital.is_umc():
                    umc_data.append(hospital)
                else:
                    not_umc_data.append(hospital)

            not_umc_died = [h.get_total_real_died_number() for h in not_umc_data]
            not_umc_admission = [h.get_total_admissions_number() / 1000 for h in not_umc_data]
            umc_died = [h.get_total_real_died_number() for h in umc_data]
            umc_admission = [h.get_total_admissions_number() / 1000 for h in umc_data]

            # Change font of the plot
            rcParams['font.family'] = 'sans-serif'
            rcParams['font.sans-serif'] = ['Tahoma', 'DejaVu Sans',
                                           'Lucida Grande', 'Verdana']
            # Create the plot
            ax = plt.subplot(111)
            ax.scatter(not_umc_admission, not_umc_died, alpha=0.50, color="#2300A8")
            ax.scatter(umc_admission, umc_died, alpha=0.50, color="#00A658")

            # Add labels
            ax.set_title('Number of hosital deads over the number of patiënt admissions')
            ax.set_ylabel('Number of hospital deads')
            ax.set_xlabel('Number of patiënt admissions (x1000)')

            # Change splines
            ax.spines['right'].set_visible(False)
            ax.spines['top'].set_visible(False)
            ax.spines['left'].set_alpha(0.4)
            ax.spines['bottom'].set_alpha(0.4)
            ax.yaxis.set_ticks_position('left')
            ax.xaxis.set_ticks_position('bottom')

            # Add grid
            ax.grid(color='grey', linestyle='-', linewidth=0.25, alpha=0.4)

            # Add legend
            legend = ax.legend(["General hosital", "University hosital"], title="Type of hosital")
            plt.setp(legend.get_title(), fontsize='11')

    def show_plot(self):
        """
        Method to display the plot
        :return:
        """

        plt.show()
