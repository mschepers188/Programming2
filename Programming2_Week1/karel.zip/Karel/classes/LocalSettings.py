from utilities import get_project_root_dir
import json
import os


class LocalSettings:
    """
    Class to utilize local_settings.json
    """
    class __LocalSettings:
        """
        Singleton class to load and get local_settings
        """
        def __init__(self):
            """
            __init__ variables:
            self.settings (None)
            self.load_settings()
            """
            self.settings = None
            self.load_settings()

        def load_settings(self):
            """
            Method to load the local_settings.json
            :return: Missing
            """
            print("Loading settings...")
            settings_path = os.path.join(get_project_root_dir(), "local_settings.json")
            settings_content = open(settings_path)
            settings = json.loads(settings_content.read())
            self.settings = settings

        def is_settings_loaded(self):
            """
            Method to check if settings are loaded
            :return: Boolean
            """
            return self.settings != None

        def get_setting(self, setting_key):
            """
            Method to return the value of a local_setting
            :param setting_key: str, key in local_settings
            :return: int/str, value of setting_key
            """
            if self.settings != None and setting_key in self.settings:
                return self.settings[setting_key]

        def get_all_settings(self):
            """
            Method to return all local_settings
            :return: dict
            """
            return self.settings

        def __str__(self):
            """
            __str__ method to return a repr of self
            :return: repr(self)
            """
            return repr(self)

    instance = None

    def __new__(cls):
        """
        Class method to set localsettings instance
        :return: instance
        """
        if not LocalSettings.instance:
            LocalSettings.instance = LocalSettings.__LocalSettings()
        return LocalSettings.instance

    def __init__(self):
        """
        __init__ method to set instance to LocalSettings._LocalSettings()
        """
        if not LocalSettings.instance:
            LocalSettings.instance = LocalSettings.__LocalSettings()

    def __getattr__(self, name):
        """
        Method to return the value of the named attribute of name
        :param name: str
        :return: str
        """
        return getattr(self.instance, name)