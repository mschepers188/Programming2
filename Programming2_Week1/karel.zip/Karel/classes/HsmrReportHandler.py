from classes.CcsHospitalInfo import CcsHospitalInfo
from classes.HsmrFileParsers.HsmrParserFactory import HsmrParserFactory
from classes.HsmrFileParsers.parserTypes import HSMR_REPORT_PDF, HSMR_REPORT_TEXT
import os
from classes.LocalSettings import LocalSettings


class HsmrReportHandler:
    localSettings = LocalSettings()

    def __init__(self, report_path, ccs_category_data):
        """
        Class to Handle the parsing and extracting of the CCS information. This class use the different
        parsers to parse and extract the data
        :param report_path: Path to HSMR pdf report
        :param ccs_category_data: CcsClassification object
        """

        self.file_path = report_path
        self.ccs_category_data = ccs_category_data
        parts = report_path.replace(".pdf", "")
        parts = parts.split("/")
        parts = parts[-1].split("_")

        self.hospital_type = parts[1]
        self.hospital_code = parts[2]
        self.hospital_name = parts[3]
        self.hospital_place = parts[4]

    def get_ccs_info(self):
        """
        Method get the ccs info from the orginal PDF report or
        from temporary parsed CCS information CSV file or from the temporary saved txt file of the PDF report.
        The temporary files prevent the reading of the entire PDF file which is time consuming
        :return:
        """

        ccs_hospital_info = CcsHospitalInfo.get_from_csv(self.hospital_type,
                                                         self.hospital_code,
                                                         self.hospital_name,
                                                         self.hospital_place)
        if ccs_hospital_info is None:
            file_path_text = os.path.join(self.localSettings.get_setting("temp_dir"),
                                          "hsmr-text_{type}_{code}_{name}_{city}.txt".format(
                type=self.hospital_type,
                code=self.hospital_code,
                name=self.hospital_name,
                city=self.hospital_place
            ))
            if os.path.isfile(file_path_text):
                hsmr_parser = HsmrParserFactory.get_instance(HSMR_REPORT_TEXT)
                file_path = file_path_text
                create_output_file = False

            else:
                hsmr_parser = HsmrParserFactory.get_instance(HSMR_REPORT_PDF)
                file_path = self.file_path
                create_output_file = True

            hospital_report = hsmr_parser(file_path,
                                          self.hospital_type,
                                          self.hospital_code,
                                          self.hospital_name,
                                          self.hospital_place)
            hospital_report.read_file()
            if create_output_file:
                hospital_report.write_content_to_text_file(file_path_text)

            ccs_hospital_info = hospital_report.extract_ccs_numbers(self.ccs_category_data)

            if ccs_hospital_info is not None:
                ccs_hospital_info.create_csv_file()
        return ccs_hospital_info
