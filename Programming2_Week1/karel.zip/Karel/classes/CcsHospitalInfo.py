from classes.LocalSettings import LocalSettings
from classes.AgbCode.hospital_types import ACADEMY_HOSPITAL
import os
import pandas as pd


class CcsHospitalInfo:
    csv_template = "ccs-data_{type}_{code}_{name}_{city}.csv"
    localSettings = LocalSettings()

    def __init__(self, hospital_type, hospital_code, hospital_name, hospital_place, ccs_df):
        """
        Class to save the CCS information of a single hospital
        :param hospital_type: String, constants defined in hosital_types.py
        :param hospital_code: String Agb code of the hostipal
        :param hospital_name: String, the hospital name
        :param hospital_place: String, the city whrere the posital is located
        :param ccs_df: Pandas Dataframe with the CCS information
        """

        self.hospital_type = hospital_type
        self.hospital_code = hospital_code
        self.hospital_name = hospital_name
        self.hospital_place = hospital_place
        self.df = ccs_df

    def get_dataframe(self):
        """
        Method to get the Pandas dataframe with the CCS information
        :return: Pandas Dataframe
        """

        return self.df

    def get_hospital_name(self):
        """
        Method to get the hospital name
        :return: string
        """

        return self.hospital_name

    def get_hospital_type(self):
        """
        Method to get the hospital type
        :return: string
        """

        return self.hospital_type

    def is_umc(self):
        """
        Method to check if this hospital is a University hospital
        :return:
        """

        return self.hospital_type == ACADEMY_HOSPITAL

    def get_real_died_values(self):
        """
        Method to get the real_died values from the CCS information
        :return: Numpy array
        """

        return self.df.loc[:, "real_died"].values

    def get_total_real_died_number(self):
        """
        Method to get the total died persons of the CCS information
        :return: int
        """

        return self.get_real_died_values().sum()

    def get_admissions_values(self):
        """
        Method to get the patiënt admission values from the CCS information
        :return: Numpy array
        """

        return self.df.loc[:, "admissions"].values

    def get_total_admissions_number(self):
        """
        Method to get the total patiënt admission number from the CCS information
        :return: int
        """

        return self.get_admissions_values().sum()

    def create_csv_file(self):
        """
        Method to create a csv file with the CCS data
        :return:
        """

        file_name = self.csv_template.format(
            type=self.hospital_type,
            code=self.hospital_code,
            name=self.hospital_name,
            city=self.hospital_place
        )
        file_path = os.path.join(self.localSettings.get_setting("temp_dir"), file_name)
        self.df.to_csv(file_path)

    @classmethod
    def get_from_csv(cls, hospital_type, hospital_code, hospital_name, hospital_place):
        """
        Method to extract the CCS information from a CSV file. The method checks if a
        CSV file is present in the temporary directory based on the given information of the hospital
        If the CSV file is present, the data will be extracted and a CcsHospitalInfo object are returned.
        None will be returned if no corresponded csv file is present
        :param hospital_type: String, constants defined in hosital_types.py
        :param hospital_code: String Agb code of the hostipal
        :param hospital_name: String, the hospital name
        :param hospital_place: String, the city whrere the posital is located
        :return: CcsHospitalInfo object when the CSV is present otherwise None
        """

        file_path = cls.csv_template.format(
            type=hospital_type,
            code=hospital_code,
            name=hospital_name,
            city=hospital_place
        )
        file_path = os.path.join(cls.localSettings.get_setting("temp_dir"), file_path)
        if os.path.isfile(file_path):
            df = pd.read_csv(file_path)
            return CcsHospitalInfo(hospital_type, hospital_code, hospital_name, hospital_place, df)

        return None
