from unittest import TestCase
from utilities import get_clean_number_list


class TestGet_clean_number_list(TestCase):
    def test_get_clean_number_list(self):
        numbers = get_clean_number_list(['', '', "5", "B", "-", "12d"])
        self.assertListEqual(numbers, [5, 13, 0, 12])

    def test_get_clean_number_list_empty(self):
        numbers = get_clean_number_list([])
        self.assertListEqual(numbers, [])